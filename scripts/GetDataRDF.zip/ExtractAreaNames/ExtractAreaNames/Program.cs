﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace ExtractAreaNames
{
    class Program
    {
        static void Main(string[] args)
        {
            string fileName = args[0];
            string outFileName = fileName + "_areas.csv";
            List<string> comb = new List<string>();
            try
            {
                TextReader sr = new StreamReader(fileName);
                TextWriter tw = new StreamWriter(outFileName);
                string lineOfText;
                while (!string.IsNullOrEmpty(lineOfText = sr.ReadLine()))
                {
                    string[] values = lineOfText.Split(new char[] { '\t' });
                    string hurrURI = values[0].Substring(1, values[0].Length - 2);
                    Uri uri;
                    if (!Uri.TryCreate(hurrURI, UriKind.Absolute, out uri))
                        continue;
                    string areasStr = values[values.Length - 1];
                    if (values.Length > 11 && !string.IsNullOrEmpty(areasStr)) //// areas exists
                    {
                        
                        Uri uriResult;
                        if (!Uri.TryCreate(areasStr.Substring(1, areasStr.Length - 2), UriKind.Absolute, out uriResult))
                        {
                            string[] areas_1 = (values[values.Length - 1]).Split(new char[] { ',' });
                            foreach (string area in areas_1)
                            {
                                if (area.Equals("\"*\"")) 
                                    continue;
                                if (!comb.Contains(string.Format("{0},{1}", hurrURI, area.Trim())))
                                {
                                    comb.Add(string.Format("{0},{1}", hurrURI, area.Trim()));
                                }
                                ///// if contains "and"
                                string[] possibleAreas = area.Split(new string[] { "and " }, StringSplitOptions.RemoveEmptyEntries);
                                foreach (string a in possibleAreas)
                                {
                                    if (string.IsNullOrEmpty(a.Trim()) || a.Equals("\"*\""))
                                        continue;
                                    if (!comb.Contains(string.Format("{0},{1}", hurrURI, a.Trim())))
                                    {
                                        comb.Add(string.Format("{0},{1}", hurrURI, a.Trim()));
                                    }
                                }
                            }
                        }
                        

                    }
                    
                }
                foreach (string rdfLine in comb)
                {
                    tw.WriteLine(rdfLine);
                }                 
                tw.Flush();
                tw.Close();
                sr.Close();
            }
            catch(Exception ex) { Console.WriteLine("error " + ex.Message); }
        }
    }
}

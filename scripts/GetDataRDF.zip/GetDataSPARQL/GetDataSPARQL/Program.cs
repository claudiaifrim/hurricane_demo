﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VDS.RDF.Query;
using VDS.RDF;
using VDS.RDF.Parsing;
using System.IO;

namespace GetDataSPARQL
{
    class Program
    {
        public static string CmdPredicateValues = @"PREFIX gn: <http://www.geonames.org/ontology#>
PREFIX wgs84: <http://www.w3.org/2003/01/geo/wgs84_pos#>
SELECT ?geoLocation ?code ?name ?countryName ?country ?provincepop ?countrypop ?geoLat ?geoLong ?countryLat ?countryLong
WHERE{{
  ?geoLocation gn:featureClass <http://www.geonames.org/ontology#A> ;
    gn:featureCode ?code .
  ?geoLocation gn:population ?provincepop .
  ?geoLocation wgs84:lat ?geoLat .
  ?geoLocation wgs84:long ?geoLong .
  OPTIONAL {{
    ?geoLocation gn:parentCountry ?country .
    ?country gn:name ?countryName .
    ?country gn:population ?countrypop .
    ?country wgs84:lat ?countryLat .
    ?country wgs84:long ?countryLong .
  }}
  FILTER(?code = <http://www.geonames.org/ontology#A.ADM1> || ?code = <http://www.geonames.org/ontology#A.PCLI> || ?code = <http://www.geonames.org/ontology#A.PCLD>)
  ?geoLocation gn:name ?name .
  FILTER(CONTAINS(?name, '{0}')) 
}}";
        static void Main(string[] args)
        {
            Execute(args[0]);

            Console.WriteLine("Press any key to contimue...");
            Console.ReadLine();
        }

        private static void Execute(string fileName)
        {
            List<string> geogrInfo = new List<string>();
            List<string> hurrPlace = new List<string>();
            Uri uri = new Uri("http://10.15.120.1:8890/sparql");
            TextReader sr = new StreamReader(fileName);
            TextWriter tw = new StreamWriter(fileName + "_updated.tsv");
            string lineOfText;
            while (!string.IsNullOrEmpty(lineOfText = sr.ReadLine()))
            {
                string[] values = lineOfText.Split(new char[] { ',' });
                string hurrURI = values[0].Replace("\"", string.Empty); //// remove all quotes
                string placeStr = values[1].Replace("\"", string.Empty).Trim();
                if (!hurrPlace.Contains(hurrURI + placeStr))
                {
                    hurrPlace.Add(hurrURI + placeStr);
                }
                else
                    continue;
                List<string> tuples = GetGeoNamesValues(uri, placeStr);
                foreach (string item in tuples)
                {
                    string csvRow = string.Format("{0}\t{1}\t{2}", hurrURI, placeStr, item);
                    //Console.WriteLine(csvRow);
                    if (!geogrInfo.Contains(csvRow))
                    {
                        geogrInfo.Add(csvRow);
                        tw.WriteLine(csvRow);
                    }
                }
            }
            tw.Flush();
            tw.Close();
            sr.Close();
        }

        private static List<string> GetGeoNamesValues(Uri endpoint, string value)
        {
            SparqlQueryParser parser = new SparqlQueryParser();
            List<string> retList = new List<string>();
            try
            {
                Uri sparqlEndpointUri = endpoint; //UriFactory.Create(txtDefaultSPARQLEndpointAddress.Text);

                //Then we can parse a SPARQL string into a query
                string sparqlQ = string.Format(CmdPredicateValues, value.Trim());
                SparqlQuery overheadQuery = parser.ParseFromString(sparqlQ); //// it is URL
                overheadQuery.Timeout = 100 * 1000;
                System.Diagnostics.Stopwatch watch = System.Diagnostics.Stopwatch.StartNew(); //// measure the execution time
                SparqlRemoteEndpoint sre = new SparqlRemoteEndpoint(sparqlEndpointUri);
                sre.Timeout = 100 * 1000;
                RemoteQueryProcessor rqp = new RemoteQueryProcessor(sre);
                object obj = rqp.ProcessQuery(overheadQuery);
                watch.Stop();
                long elapsedMs = watch.ElapsedMilliseconds;
                //string[] values = { endpoint.ToString(), string.Format(CmdPredicateValues, "<" + predicate.Trim() + ">"), elapsedMs.ToString(), false.ToString(), DateTime.Now.ToString("yyyy-MM-dd hh:mm") };
                if (obj is SparqlResultSet)
                {
                    SparqlResultSet resultSet = (SparqlResultSet)obj;
                    if (resultSet.Result || resultSet.Count > 0)
                    {
                        retList = ConvertResultToStringList(resultSet);
                    }
                }
                //else
                //{
                //    Logger.log(string.Format("During the execution of the query result is wrong {0}", obj.ToString()));
                //}
                //CSVLogger.Instance().log(values.ToArray());
            }
            catch (Exception ex)
            {
                string errorStr = string.Format("Error occurred: {0}, Value {2}, StackTrace: {1}", ex.Message, ex.StackTrace, value);
                if (ex.InnerException != null)
                    errorStr = string.Format("Error occurred: {0}, InnerException: {1}, StackTrace: {2}", ex.Message, ex.InnerException.Message, ex.StackTrace);
                Console.WriteLine(errorStr);
                //Logger.log(string.Format("{0} - During the execution of the query the following error occurred: {1} ", endpoint.ToString(), errorStr));
                //string[] values = { endpoint.ToString(), string.Format(CmdPredicateValues, "<" + predicate.Trim() + ">"), ex.Message, false.ToString(), DateTime.Now.ToString("yyyy-MM-dd hh:mm") };
                //CSVLogger.Instance().log(values.ToArray());
            }
            return retList;
        }

        /// <summary>
        /// comma separated string
        /// </summary>
        /// <param name="rset"></param>
        /// <returns></returns>
        public static List<string> ConvertResultToStringList(SparqlResultSet rset)
        {

            List<string> retLst = new List<string>();
            int rowNr = 0;
            string geoLocation = string.Empty;
            string countryLocation = string.Empty;
            string countryName = string.Empty;
            string provinceName = string.Empty;
            string countrypop = string.Empty;
            string provincepop = string.Empty;
            string geoLat = string.Empty;
            string geoLong = string.Empty;
            string countryLat = string.Empty;
            string countryLong = string.Empty;
            foreach (SparqlResult result in rset)
            {
                INode n;
                if (result.TryGetValue("geoLocation", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Uri:
                                geoLocation = (((IUriNode)n).Uri.AbsoluteUri).ToString();
                                break;
                            default:
                                break;
                        }
                    }
                }
                if (result.TryGetValue("country", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Uri:
                                countryLocation = (((IUriNode)n).Uri.AbsoluteUri).ToString();
                                break;
                            default:
                                break;
                        }
                    }
                }
                if (result.TryGetValue("name", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    provinceName = ((ILiteralNode)n).Value;
                                else
                                    provinceName = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("countryName", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    countryName = ((ILiteralNode)n).Value;
                                else
                                    countryName = "N/A";
                                break;
                            default:
                                break;
                        }
                    }
                }
                if (result.TryGetValue("provincepop", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    provincepop = ((ILiteralNode)n).Value;
                                else
                                    provincepop = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("countrypop", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    countrypop = ((ILiteralNode)n).Value;
                                else
                                    countrypop = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("geoLat", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    geoLat = ((ILiteralNode)n).Value;
                                else
                                    geoLat = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("geoLong", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    geoLong = ((ILiteralNode)n).Value;
                                else
                                    geoLong = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("countryLat", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    countryLat = ((ILiteralNode)n).Value;
                                else
                                    countryLat = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("countryLong", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Literal:
                                //You may want to inspect the DataType and Language properties and generate
                                //a different string here
                                ILiteralNode node = ((ILiteralNode)n);
                                if (!((ILiteralNode)n).Value.Equals("NAN"))
                                    countryLong = ((ILiteralNode)n).Value;
                                else
                                    countryLong = "N/A";
                                break;
                        }
                    }
                }
                if (result.TryGetValue("code", out n))
                {
                    if (n != null)
                    {
                        switch (n.NodeType)
                        {
                            case NodeType.Uri:
                                if ((((IUriNode)n).Uri.AbsoluteUri).ToString().Equals("http://www.geonames.org/ontology#A.ADM1"))
                                    Console.Write(""); //// it is a province
                                else if ((((IUriNode)n).Uri.AbsoluteUri).ToString().Equals("http://www.geonames.org/ontology#A.PCLI") ||
                                    (((IUriNode)n).Uri.AbsoluteUri).ToString().Equals("http://www.geonames.org/ontology#A.PCLD"))
                                {
                                    countryName = provinceName;
                                    countryLocation = geoLocation;
                                    countrypop = provincepop;
                                    countryLat = geoLat;
                                    countryLong = geoLong;
                                    provinceName = string.Empty;
                                    geoLocation = string.Empty;
                                    provincepop = string.Empty;
                                    geoLat = string.Empty;
                                    geoLong = string.Empty;
                                }
                                break;
                            default:
                                break;
                        }
                    }
                }

                retLst.Add(string.Format("{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}\t{9}", countryName, countryLocation, countrypop, provinceName, geoLocation, provincepop, geoLat, geoLong, countryLat, countryLong));
                rowNr++;
            }
            return retLst;
        }
    }
}
